/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  FileText, 
  Folder, 
  FolderOpen, 
  ChevronRight, 
  Database, 
  Cpu, 
  Layers, 
  Download, 
  Copy, 
  History, 
  Compass, 
  CheckCircle, 
  ShieldCheck, 
  Code,
  Terminal,
  Activity,
  Calendar,
  AlertCircle,
  RefreshCw
} from "lucide-react";
import WinSimulator from "./components/WinSimulator";
import { FileNode, TableSchema, LicenseState } from "./types";

export default function App() {
  const [architectureSpec, setArchitectureSpec] = useState<any>(null);
  const [dbSchema, setDbSchema] = useState<TableSchema[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [fileAncestors, setFileAncestors] = useState<string[]>([]);
  const [generatedCode, setGeneratedCode] = useState<string>("");
  const [codeLoading, setCodeLoading] = useState<boolean>(false);
  const [copySuccess, setCopySuccess] = useState<string | null>(null);

  // License activation state values (simulated but synced)
  const [licenseState, setLicenseState] = useState<LicenseState>({
    active: false,
    rawKey: "",
    hardwareHash: "DF-B981-AEC2-315A-9D22-FF81",
    activatedAt: "",
    expiresAt: "",
    daysRemaining: 0,
    tier: "Evaluation Mode",
    reason: "",
  });

  // Database simulator logs showing user SQL queries executed of SQLite actions
  const [mockDatabaseLogs, setMockDatabaseLogs] = useState<any[]>([
    {
      timestamp: new Date().toLocaleTimeString(),
      action: "Database Initialized",
      sql: "PRAGMA journal_mode = WAL;\nCREATE TABLE IF NOT EXISTS license_info (...);\nCREATE TABLE IF NOT EXISTS conversion_history (...);"
    }
  ]);

  // Expose portal generator
  const [portalDays, setPortalDays] = useState<number>(90);
  const [portalGeneratedKey, setPortalGeneratedKey] = useState<string>("");

  useEffect(() => {
    // Fetch architectural specifications from Express backend
    fetch("/api/architect/spec")
      .then((res) => res.json())
      .then((data) => {
        setArchitectureSpec(data.architecture);
        setDbSchema(data.schema);
        
        // Auto-select main.py by default
        if (data.architecture?.folderStructure) {
          const mainFile = findFileByName(data.architecture.folderStructure, "main.py");
          if (mainFile) {
            handleFileSelect(mainFile, ["docuforge"]);
          }
        }
      })
      .catch((err) => console.error("Error loading architecture specs:", err));
  }, []);

  const findFileByName = (node: FileNode, name: string): FileNode | null => {
    if (node.name === name) return node;
    if (node.children) {
      for (const child of node.children) {
        const found = findFileByName(child, name);
        if (found) return found;
      }
    }
    return null;
  };

  const handleFileSelect = (node: FileNode, path: string[]) => {
    setSelectedFile(node);
    setFileAncestors(path);
    setGeneratedCode("");
    setCodeLoading(true);

    const relativePath = [...path, node.name].join("/");
    
    // Request implementation blueprint from server-side AI template or fallback
    fetch("/api/architect/generate-code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filePath: relativePath, description: node.description })
    })
      .then((res) => res.json())
      .then((data) => {
        setGeneratedCode(data.code);
        setCodeLoading(false);
      })
      .catch((err) => {
        console.error("Error generating code:", err);
        setGeneratedCode("# Failed to establish connection with AI generation microservice.");
        setCodeLoading(false);
      });
  };

  const generateLicensePortalKey = () => {
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + portalDays);
    const dateStr = expiryDate.toISOString().split("T")[0];
    
    const payload = {
      hwid: licenseState.hardwareHash,
      expiry: dateStr,
      tier: "enterprise",
      salt: "DF99OfflineKeySaltPattern"
    };

    const b64 = btoa(JSON.stringify(payload));
    const generated = `DF-${b64}`;
    setPortalGeneratedKey(generated);
    
    setMockDatabaseLogs(prev => [
      {
        timestamp: new Date().toLocaleTimeString(),
        action: "Portal license generated",
        sql: `-- Key generated in Cloud Portal for user HWID ${licenseState.hardwareHash}\n-- Bound Expiration: ${dateStr} (${portalDays} days Validity)`
      },
      ...prev
    ]);
  };

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopySuccess("Copied!");
    setTimeout(() => setCopySuccess(null), 2000);
  };

  const addHistoryLog = (item: any) => {
    // Adds a history log simulating success or failures
    setMockDatabaseLogs(prev => [
      {
        timestamp: new Date().toLocaleTimeString(),
        action: "Process Log Insert",
        sql: `INSERT INTO conversion_history (source_file_name, source_file_type, destination_file_path, conversion_type, status, total_pages, duration_seconds) VALUES ('${item.sourceName}', '${item.sourceType}', '${item.destinationPath}', '${item.conversionType}', 'SUCCESS', ${item.totalPages}, ${item.durationSeconds});`
      },
      ...prev
    ]);
  };

  // Node renderer for beautiful folder hierarchy structures code layout
  const renderTree = (node: FileNode, path: string[] = []): React.ReactNode => {
    const isDir = node.type === "directory";
    const currentPath = [...path, node.name];
    const isSelected = selectedFile?.name === node.name && fileAncestors.join("/") === path.join("/");

    return (
      <div key={node.name} className="pl-3.5 select-none font-sans">
        <div 
          onClick={() => {
            if (!isDir) {
              handleFileSelect(node, path);
            }
          }}
          className={`group flex items-center gap-1.5 py-1 px-2 rounded-md text-xs cursor-pointer transition-all ${
            isDir 
              ? "text-slate-300 hover:text-white" 
              : isSelected
              ? "bg-sky-500/15 border border-sky-500/30 text-sky-450 font-medium"
              : "text-slate-400 hover:bg-slate-800/45 hover:text-slate-200 border border-transparent"
          }`}
        >
          {isDir ? (
            <Folder className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
          ) : (
            <FileText className="w-3.5 h-3.5 text-sky-500 shrink-0" />
          )}
          <span className="truncate">{node.name}</span>
          {!isDir && (
            <span className="opacity-0 group-hover:opacity-100 text-[10px] text-sky-400 font-mono ml-auto">
              Inspect →
            </span>
          )}
        </div>
        
        {isDir && node.children && (
          <div className="border-l border-slate-800 ml-1.5 mt-0.5 mb-1 pl-1">
            {node.children.map(child => renderTree(child, currentPath))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-sky-500 selection:text-white font-sans overflow-x-hidden pb-12">
      
      {/* Visual Workspace Hero Segment (Zero slop, pure engineering luxury) */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-600/10 rounded-lg border border-sky-500/20">
              <Compass className="w-6 h-6 text-sky-500" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display font-bold text-lg tracking-tight text-white leading-none">
                  DocuForge AI Converter
                </h1>
                <span className="text-[10px] uppercase tracking-wider font-mono px-2 py-0.5 rounded bg-sky-500/10 border border-sky-500/20 text-sky-400">
                  Architect Workspace
                </span>
              </div>
              <p className="text-xs text-slate-405 text-slate-400 mt-0.5">
                Offline Document Conversion & AI-Powered Table Reconstruction Engine Spec.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-[11px] font-mono bg-slate-800 px-2.5 py-1 rounded border border-transparent text-slate-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Local Active Port: 3000 (Proxy Verified)
            </span>
            <a 
              href="#sandbox" 
              className="px-3.5 py-1.5 rounded bg-sky-600 hover:bg-sky-500 text-xs font-semibold text-white transition-all shadow-md active:translate-y-0.5 flex items-center gap-1.5"
            >
              <Activity className="w-3.5 h-3.5" />
              Launch Sandboxed Windows Sim
            </a>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 mt-8 space-y-8">
        
        {/* Core Architecture Matrix Panels */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Panel 1: Key Project Core Specs */}
          <div className="glass-panel rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Layers className="w-4.5 h-4.5 text-sky-500" />
              <h3 className="font-display font-bold text-xs uppercase tracking-wider text-slate-350 text-sky-400">
                1. Standalone Core Specs
              </h3>
            </div>

            <div className="space-y-3.5 text-xs text-slate-300">
              <p className="leading-relaxed">
                Premium production suite designed to operate inside standard isolated consumer windows workstations with zero cloud network egress requirements.
              </p>
              
              <div className="space-y-2 font-mono">
                <div className="p-2 bg-slate-900 border border-slate-800/80 rounded flex justify-between items-center">
                  <span className="text-slate-500 text-[11px]">OCR ENGINE</span>
                  <span className="text-sky-400 font-semibold text-[11px]">PaddleOCR v4 Light</span>
                </div>

                <div className="p-2 bg-slate-900 border border-slate-800/80 rounded flex justify-between items-center">
                  <span className="text-slate-500 text-[11px]">PDF COMPILATION</span>
                  <span className="text-sky-400 font-semibold text-[11px]">PyMuPDF (fitz)</span>
                </div>

                <div className="p-2 bg-slate-900 border border-slate-800/80 rounded flex justify-between items-center">
                  <span className="text-slate-500 text-[11px]">DOCX COMPOSITION</span>
                  <span className="text-emerald-500 font-semibold text-[11px]">python-docx (Native Flow)</span>
                </div>

                <div className="p-2 bg-slate-900 border border-slate-800/80 rounded flex justify-between items-center">
                  <span className="text-slate-500 text-[11px]">CACHE ENGINE</span>
                  <span className="text-indigo-400 font-semibold text-[11px]">SQLite (WAL mode)</span>
                </div>
              </div>

              <div className="rounded p-3 bg-sky-500/5 border border-sky-500/15">
                <div className="flex gap-2 items-start">
                  <AlertCircle className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
                  <p className="text-[11px] leading-relaxed text-slate-400">
                    Formatting preservation is engineered through dynamic paragraph coordinate grouping and relative spatial clustering computation algorithms.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Panel 2: Offline 3-Month Renewable License Cryptography */}
          <div className="glass-panel rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <ShieldCheck className="w-4.5 h-4.5 text-emerald-400" />
              <h3 className="font-display font-bold text-xs uppercase tracking-wider text-emerald-400">
                2. Licensing & Bounding Specs
              </h3>
            </div>

            <div className="space-y-3 text-xs leading-relaxed">
              <p className="text-slate-300">
                The offline license key validates subscription rights inside secure workstation silos through hardware cryptographic salt comparisons.
              </p>

              <ul className="space-y-2 text-slate-400">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span><b>Hardware ID Lock:</b> Binds bios UUID and CPU registers.</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span><b>3-Month Expiry:</b> Decodes absolute duration timeline.</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span><b>Clock Tampering Sensors:</b> Monitors SQLite timestamp deltas.</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span><b>AES Decryption:</b> Handled inside the activation state checks.</span>
                </li>
              </ul>

              {/* License Portal key generator */}
              <div className="mt-3 bg-slate-900 border border-slate-800 p-2.5 rounded space-y-2">
                <span className="text-[10px] font-mono font-semibold text-slate-400 block uppercase">
                  🔑 Cloud Activation Keys Generator (Demo Portal)
                </span>
                
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>Active Subscription:</span>
                    <span className="font-mono text-zinc-300">{portalDays} Days</span>
                  </div>
                  <input
                    type="range"
                    min="30"
                    max="365"
                    step="30"
                    value={portalDays}
                    onChange={(e) => setPortalDays(parseInt(e.target.value))}
                    className="w-full accent-sky-500 bg-slate-850 h-1 rounded"
                  />
                </div>

                <div className="flex gap-1.5">
                  <button
                    onClick={generateLicensePortalKey}
                    className="flex-1 text-[10px] py-1 bg-sky-600 hover:bg-sky-500 font-semibold text-white rounded text-center transition-colors shadow"
                  >
                    Generate bound Register Key
                  </button>
                </div>

                {portalGeneratedKey && (
                  <div className="space-y-1 pt-1 border-t border-slate-800">
                    <span className="text-[9px] text-emerald-400 block">✓ Key generated for active hardware!</span>
                    <div className="flex items-center gap-1 bg-slate-955 p-1 rounded border border-slate-800">
                      <input
                        type="text"
                        readOnly
                        value={portalGeneratedKey}
                        className="bg-transparent text-[8px] font-mono text-slate-350 focus:outline-none flex-1 overflow-hidden text-ellipsis selection:bg-slate-700"
                      />
                      <button 
                        onClick={() => handleCopyCode(portalGeneratedKey)}
                        className="hover:text-emerald-400 p-0.5 shrink-0"
                        title="Copy Key"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Panel 3: Complete SQLite Schema Definitions */}
          <div className="glass-panel rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Database className="w-4.5 h-4.5 text-indigo-400" />
              <h3 className="font-display font-bold text-xs uppercase tracking-wider text-indigo-400">
                3. Local Database Schema
              </h3>
            </div>

            <div className="space-y-3">
              <p className="text-xs text-slate-400 leading-relaxed">
                SQLite local connection provides robust audit logs for operations tracking, license duration hashes, and coordinate layouts caching.
              </p>

              {dbSchema.length > 0 && (
                <div className="space-y-1.5">
                  {dbSchema.map((item, idx) => (
                    <div 
                      key={item.table} 
                      className="p-2 border border-slate-800 hover:border-slate-700 rounded bg-slate-900/60 font-sans transition-all"
                    >
                      <div className="flex items-center gap-1.5 justify-between">
                        <span className="font-mono font-bold text-xs text-slate-205 text-indigo-300">
                          {item.table}
                        </span>
                        <span className="text-[9px] opacity-70 px-1 py-0.2 bg-indigo-500/10 text-indigo-400 font-mono rounded">
                          SQLite
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1 leading-snug">
                        {item.description}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              <div className="p-2.5 rounded bg-amber-500/5 text-[10px] leading-relaxed text-amber-500 border border-amber-500/15">
                Ensure multi-threaded reads are safe from resource deadlocks by configuring WAL flags on connection handles.
              </div>
            </div>
          </div>

        </section>

        {/* Modular Python Template Explorer System */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Tree list mapping column spans - 4 columns */}
          <div className="lg:col-span-4 glass-panel rounded-xl p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                <Code className="w-5 h-5 text-sky-400" />
                <div>
                  <h3 className="font-display font-bold text-sm tracking-wide text-white">
                    Python Repository Blueprints
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Click any module path below to inspect its production-grade class template.
                  </p>
                </div>
              </div>

              {architectureSpec?.folderStructure ? (
                <div className="py-2 px-1 max-h-96 overflow-y-auto custom-scrollbar space-y-1">
                  {renderTree(architectureSpec.folderStructure)}
                </div>
              ) : (
                <div className="text-center py-6 text-slate-500 text-xs font-mono">
                  Loading blueprints...
                </div>
              )}
            </div>

            <div className="space-y-2 border-t border-slate-800/80 pt-4">
              <span className="text-[10px] font-mono text-slate-500 uppercase block">Selected Block Description:</span>
              <div className="p-3 bg-slate-900 border border-slate-800 rounded min-h-16 text-xs leading-relaxed text-slate-450 text-slate-300">
                {selectedFile ? (
                  <div>
                    <div className="font-bold text-sky-400 text-[11px] font-mono mb-1">{selectedFile.name}</div>
                    <p>{selectedFile.description || "Core engine system script"}</p>
                  </div>
                ) : (
                  <span className="text-slate-500 font-mono">No repository file selected.</span>
                )}
              </div>
            </div>
          </div>

          {/* Real-time Code Viewer - 8 columns */}
          <div className="lg:col-span-8 glass-panel rounded-xl p-5 flex flex-col justify-between min-h-[460px]">
            <div className="space-y-3.5 flex-1 flex flex-col justify-between">
              
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
                    <Terminal className="w-4.5 h-4.5 text-zinc-400" />
                    <span>Real-time Implementation Code</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Generated on-the-fly dynamically using Google Gemini for standard offline packaging.
                  </p>
                </div>

                {generatedCode && (
                  <div className="flex items-center gap-2">
                    {copySuccess && <span className="text-xs text-emerald-500 font-mono">{copySuccess}</span>}
                    <button
                      onClick={() => handleCopyCode(generatedCode)}
                      className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 transition-colors border border-slate-700 rounded text-slate-300 flex items-center gap-1.5"
                    >
                      <Copy className="w-3.5 h-3.5" /> Copy Class Code
                    </button>
                  </div>
                )}
              </div>

              {/* Display generated code with scrollable styling */}
              <div className="flex-1 mt-2.5 relative min-h-64">
                {codeLoading ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/40 rounded-lg">
                    <RefreshCw className="w-8 h-8 text-sky-500 animate-spin mb-2" />
                    <span className="text-xs font-mono text-slate-400">Reconstructing Python class architecture...</span>
                  </div>
                ) : (
                  <textarea
                    readOnly
                    value={generatedCode || "# Please choose a module from the left tree."}
                    className="w-full h-96 p-4 rounded-lg bg-slate-950 text-slate-300 font-mono text-[11px] leading-relaxed border border-slate-850 outline-none resize-none custom-scrollbar shadow-inner"
                  />
                )}
              </div>

            </div>

            <div className="mt-4 border-t border-slate-850 pt-3 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
              <span>Code generated validates typing safety variables, logging systems, and explicit exception cleanups.</span>
              <span>Python 3.10+ • PySide6 • stand-alone</span>
            </div>
          </div>

        </section>

        {/* Windows Simulator Terminal Playground Segment (Direct Sandbox testing) */}
        <section id="sandbox" className="space-y-4">
          <div className="border-l-4 border-sky-500 pl-3">
            <h2 className="font-display font-bold text-lg text-white">
              Windows PySide6 stand-alone Desktop Sim
            </h2>
            <p className="text-xs text-slate-400">
              Run offline code logic, convert fake batch items and test activation checks right within AI Studio preview frameworks. No native Windows machine needed.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
            
            {/* Multi-tier simulator frame (Takes 3 columns space) */}
            <div className="lg:col-span-3">
              <WinSimulator
                licenseState={licenseState}
                setLicenseState={setLicenseState}
                addHistoryLog={addHistoryLog}
                mockDatabaseLogs={mockDatabaseLogs}
                setMockDatabaseLogs={setMockDatabaseLogs}
              />
            </div>

            {/* Simulated Live Database Audit Column */}
            <div className="lg:col-span-1 glass-panel rounded-xl p-5 space-y-4">
              <div className="border-b border-slate-800 pb-2.5">
                <h4 className="text-xs font-bold font-display uppercase tracking-wide text-indigo-400 flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-zinc-400" /> SQL Queries Log Trace
                </h4>
                <p className="text-[10px] text-slate-500 mt-1">
                  Listens to real-time SELECT and INSERT queries executed on the SQLite engine of the simulator.
                </p>
              </div>

              <div className="space-y-3.5 max-h-[380px] overflow-y-auto custom-scrollbar">
                {mockDatabaseLogs.map((log, i) => (
                  <div key={i} className="p-2 bg-slate-950 rounded border border-slate-900 font-mono text-[9px] space-y-1 relative group">
                    <div className="flex justify-between items-center text-[8px] text-slate-500">
                      <span className="px-1 text-slate-400 bg-slate-900 border border-slate-800 rounded font-bold uppercase">{log.action}</span>
                      <span>{log.timestamp}</span>
                    </div>
                    <pre className="text-slate-300 overflow-x-auto whitespace-pre-wrap leading-relaxed break-all">
                      {log.sql}
                    </pre>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </section>

        {/* Section 5: MVP Packaging Roadmap & Phases Progress */}
        <section className="glass-panel rounded-xl p-6 space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Calendar className="w-5 h-5 text-indigo-400" />
            <div>
              <h3 className="font-display font-bold text-sm tracking-wide text-white">
                MVP Packaging Roadmap & Deployment Phases
              </h3>
              <p className="text-xs text-slate-500">
                Phase metrics designed for structured software progression from MVP blueprints towards complete client deployment.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-sans">
            
            <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-2 relative overflow-hidden group hover:border-slate-700 transition-all">
              <span className="absolute top-1 right-2 text-3xl font-bold font-display text-slate-800/50 group-hover:text-slate-800 transition-colors">01</span>
              <div className="flex gap-1.5 items-center">
                <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                <span className="font-bold text-sky-400">Core Skeleton Layout</span>
              </div>
              <p className="text-slate-400 leading-normal text-[11px]">
                Define base folder structure. Mount structural model loaders, initialize Python modules logging configuration profiles and local sqlite tables connection bounds.
              </p>
            </div>

            <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-2 relative overflow-hidden group hover:border-slate-700 transition-all">
              <span className="absolute top-1 right-2 text-3xl font-bold font-display text-slate-800/50 group-hover:text-slate-800 transition-colors">02</span>
              <div className="flex gap-1.5 items-center">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span className="font-bold text-sky-400">OCR & Document Engine</span>
              </div>
              <p className="text-slate-400 leading-normal text-[11px]">
                Bundle local PaddleOCR binary models. Bind PyMuPDF coordinates detection formulas. Connect python-docx page builders to preserve dynamic headings.
              </p>
            </div>

            <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-2 relative overflow-hidden group hover:border-slate-700 transition-all">
              <span className="absolute top-1 right-2 text-3xl font-bold font-display text-slate-800/50 group-hover:text-slate-800 transition-colors">03</span>
              <div className="flex gap-1.5 items-center">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                <span className="font-bold text-sky-450 text-sky-400">GUI Frame & licensing</span>
              </div>
              <p className="text-slate-400 leading-normal text-[11px]">
                Establish styling wrappers. Connect PySide QThreads to avoid GUI freezes on lengthy layouts computations. Wire activation salt calculations.
              </p>
            </div>

            <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-2 relative overflow-hidden group hover:border-slate-700 transition-all">
              <span className="absolute top-1 right-2 text-3xl font-bold font-display text-slate-800/50 group-hover:text-slate-800 transition-colors">04</span>
              <div className="flex gap-1.5 items-center">
                <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                <span className="font-bold text-sky-400">Packaging Deployment</span>
              </div>
              <p className="text-slate-400 leading-normal text-[11px]">
                Generate executable bundle files using PyInstaller spec instructions. Inject standard resource logos via Inno Setup scripts to make a robust offline setup.
              </p>
            </div>

          </div>
        </section>

      </main>

      {/* Primary footer */}
      <footer className="mt-12 border-t border-slate-900 py-6 text-center text-xs text-slate-500 max-w-7xl mx-auto px-4">
        <p className="leading-relaxed">
          DocuForge AI Converter Architect Suite • Standalone Offline App Blueprint • Devoted to meticulous layout preserving document conversions.
        </p>
      </footer>

    </div>
  );
}

