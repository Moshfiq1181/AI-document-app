import React, { useState, useEffect } from "react";
import { 
  FileText, 
  Settings, 
  Key, 
  RefreshCw, 
  Play, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  FolderOpen, 
  Trash2, 
  History, 
  Database, 
  ChevronRight, 
  FileDown, 
  Cpu,
  Monitor,
  Moon,
  Sun,
  ShieldAlert,
  Terminal,
  Grid
} from "lucide-react";
import { ConversionItem, LicenseState } from "../types";

interface WinSimulatorProps {
  licenseState: LicenseState;
  setLicenseState: React.Dispatch<React.SetStateAction<LicenseState>>;
  addHistoryLog: (log: any) => void;
  mockDatabaseLogs: any[];
  setMockDatabaseLogs: React.Dispatch<React.SetStateAction<any[]>>;
}

export default function WinSimulator({
  licenseState,
  setLicenseState,
  addHistoryLog,
  mockDatabaseLogs,
  setMockDatabaseLogs,
}: WinSimulatorProps) {
  // Simulator configurations
  const [qtTheme, setQtTheme] = useState<"dark" | "light">("dark");
  const [currentTab, setCurrentTab] = useState<"convert" | "history" | "settings" | "license">("convert");
  
  // Convert module states
  const [dragActive, setDragActive] = useState(false);
  const [selectedFolder, setSelectedFolder] = useState("C:\\Users\\User\\Documents\\DocuForgeExports");
  const [conversionType, setConversionType] = useState<string>("pdf_to_docx");
  const [preserveLayout, setPreserveLayout] = useState(true);
  const [ocrMode, setOcrMode] = useState<"scan" | "always" | "never">("scan");
  const [tableGridForce, setTableGridForce] = useState(true);

  // Loaded mockup files in converter queue
  const [files, setFiles] = useState<Array<{ id: string; name: string; sizeMB: number; status: string; progress: number; pages: number; ocrApplied: boolean }>>([
    { id: "1", name: "Annual_Report_2025.pdf", sizeMB: 14.2, status: "Ready", progress: 0, pages: 12, ocrApplied: false },
    { id: "2", name: "Scan_Invoice_99812_Receipt.jpg", sizeMB: 4.1, status: "Ready", progress: 0, pages: 1, ocrApplied: true },
    { id: "3", name: "Executive_Briefing.docx", sizeMB: 1.8, status: "Ready", progress: 0, pages: 3, ocrApplied: false },
  ]);

  // Terminal simulated logs
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "🎨 DocuForge PySide6 Qt Desktop Engine started in offline mode.",
    "🛡️ HWID Signature calculated: BIOS_UUID_99912A34928X",
    "💾 Local database mounted from SQLite: C:\\ProgramData\\DocuForge\\app.db",
    "✅ Validation success: Core conversions ready."
  ]);

  const [loading, setLoading] = useState(false);
  const [currentProgress, setCurrentProgress] = useState(0);
  const [runningFile, setRunningFile] = useState<string | null>(null);

  // Set default alert based on license
  useEffect(() => {
    if (!licenseState.active) {
      logTerminal("⚠️ NOTICE: Offline software running in TRIAL MODE (Restricted to 1-page per conversion).");
    } else {
      logTerminal(`🚀 Premium License Verified (Valid until ${licenseState.expiresAt}). Batch limits removed!`);
    }
  }, [licenseState.active]);

  const logTerminal = (msg: string) => {
    setTerminalLogs(prev => [...prev.slice(-30), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const newFiles = Array.from(e.dataTransfer.files).map((f: any) => ({
        id: Math.random().toString(),
        name: f.name,
        sizeMB: parseFloat((f.size / (1024 * 1024)).toFixed(2)) || 0.1,
        status: "Ready",
        progress: 0,
        pages: f.name.toLowerCase().endsWith(".pdf") ? 8 : 1,
        ocrApplied: ocrMode === "always" || (ocrMode === "scan" && !f.name.toLowerCase().endsWith(".docx"))
      }));
      setFiles(prev => [...prev, ...newFiles]);
      logTerminal(`📥 Dragged and dropped ${newFiles.length} files into offline PySide workspace.`);
    }
  };

  const removeFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const clearQueue = () => {
    setFiles([]);
    logTerminal("🧹 Cleared conversion list.");
  };

  // Run conversion pipeline simulation
  const startConversion = async () => {
    if (files.length === 0) {
      logTerminal("❌ Error: No source documents loaded in conversion queue.");
      return;
    }
    if (loading) return;

    setLoading(true);
    logTerminal("⚙️ Commencing batch conversion process on Qt MainThread...");
    
    // Simulate each file converting
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setRunningFile(file.name);
      
      // Update specific file status to running
      setFiles(prev => prev.map(f => f.id === file.id ? { ...f, status: "Processing", progress: 10 } : f));
      logTerminal(`📄 Compiling conversion profile [${conversionType}] for: ${file.name}`);
      await wait(300);

      // Check tier limit alert
      let pagesToConvert = file.pages;
      let ocrRan = file.ocrApplied;
      
      if (!licenseState.active && pagesToConvert > 1) {
        logTerminal(`⚠️ Unlicensed Trial mode active: Restricting page analysis to page 1 for: ${file.name}`);
        pagesToConvert = 1;
      }

      // Step-by-step progress logging simulating actual local Python engine methods
      logTerminal(`[PyMuPDF] Loading page buffers (Total pages to compile: ${pagesToConvert})...`);
      setFiles(prev => prev.map(f => f.id === file.id ? { ...f, progress: 30 } : f));
      await wait(450);

      if (ocrRan) {
        logTerminal(`[PaddleOCR] Launching PaddleOCR weights v4. Segments rendering horizontal layout cuts...`);
        logTerminal(`[PaddleOCR] Found ${pagesToConvert * 4} layout boxes. Writing structure grids...`);
        setFiles(prev => prev.map(f => f.id === file.id ? { ...f, progress: 65 } : f));
        await wait(500);
      } else {
        logTerminal(`[LayoutPreset] Structuring document paragraph flows, mapping margins and embedded font lists.`);
        setFiles(prev => prev.map(f => f.id === file.id ? { ...f, progress: 70 } : f));
        await wait(400);
      }

      if (tableGridForce) {
        logTerminal(`[TableEngine] Parsing coordinate shapes. Reconstructing native Word table cells.`);
        await wait(250);
      }

      const fileExtension = conversionType.split("_to_")[1];
      const targetPath = `${selectedFolder}\\${file.name.substring(0, file.name.lastIndexOf("."))}._converted.${fileExtension}`;
      
      logTerminal(`[python-docx] Binding layout buffers. Saving local document chunk directly to: ${targetPath}`);
      setFiles(prev => prev.map(f => f.id === file.id ? { ...f, status: "Completed", progress: 100 } : f));
      
      // Commit history log entry
      const elapsed = parseFloat((1.2 + Math.random() * 2.1).toFixed(2));
      const logEntry: ConversionItem = {
        id: Math.random().toString(),
        sourceName: file.name,
        sourceType: file.name.substring(file.name.lastIndexOf(".")),
        destinationPath: targetPath,
        conversionType: conversionType,
        status: "SUCCESS",
        progress: 100,
        totalPages: pagesToConvert,
        ocrApplied: ocrRan,
        durationSeconds: elapsed,
        timestamp: new Date().toLocaleTimeString(),
        sizeMB: file.sizeMB
      };
      
      // Update global database mock tables log
      addHistoryLog(logEntry);
      
      // Add row insert in SQLite logs
      setMockDatabaseLogs(prev => [
        {
          timestamp: new Date().toLocaleTimeString(),
          action: "SQLite INSERT row",
          sql: `INSERT INTO conversion_history (source_file_name, source_file_type, destination_file_path, conversion_type, status, total_pages, ocr_applied, duration_seconds) VALUES ('${file.name}', '${logEntry.sourceType}', '${targetPath}', '${conversionType}', 'SUCCESS', ${pagesToConvert}, ${ocrRan ? 1 : 0}, ${elapsed});`
        },
        ...prev
      ]);

      await wait(300);
    }

    setLoading(false);
    setRunningFile(null);
    logTerminal("✅ Successfully completed all batch conversion outputs.");
  };

  const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  return (
    <div className={`w-full rounded-xl overflow-hidden shadow-2xl border ${
      qtTheme === "dark" 
        ? "bg-slate-900 border-slate-700 text-slate-100" 
        : "bg-stone-50 border-stone-300 text-stone-800"
    }`}>
      {/* OS Sim Top Window header bar */}
      <div className={`flex items-center justify-between px-4 py-2 border-b select-none ${
        qtTheme === "dark" ? "bg-slate-950 border-slate-800" : "bg-stone-200 border-stone-300"
      }`}>
        <div className="flex items-center gap-2">
          <Monitor className="w-4 h-4 text-sky-500" />
          <span className="font-display font-semibold text-xs tracking-wide">
            DocuForge AI Converter v1.4.0 (Windows Qt GUI)
          </span>
          {!licenseState.active ? (
            <span className="px-1.5 py-0.5 rounded text-[10px] uppercase font-mono bg-amber-500/10 text-amber-500 border border-amber-500/20">
              Unlicensed Trial Mode
            </span>
          ) : (
            <span className="px-1.5 py-0.5 rounded text-[10px] uppercase font-mono bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 animate-pulse">
              Enterprise License Active
            </span>
          )}
        </div>
        
        {/* Sim buttons and light/dark theme togglers */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setQtTheme(prev => prev === "dark" ? "light" : "dark")}
            className={`p-1 rounded hover:bg-white/10 transition-colors tooltip`}
            title="Toggle Sim Theme"
          >
            {qtTheme === "dark" ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-slate-700" />}
          </button>
          
          <div className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-stone-500"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>
        </div>
      </div>

      <div className="flex min-h-[480px]">
        {/* Navigation Sidebar mimicking standard PySide lateral navigation rail */}
        <div className={`w-44 border-r select-none flex flex-col justify-between p-2 font-sans ${
          qtTheme === "dark" ? "bg-slate-950/80 border-slate-800" : "bg-stone-100 border-stone-300"
        }`}>
          <div className="space-y-1">
            <div className="px-2 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-500">
              Navigations
            </div>
            <button
              onClick={() => setCurrentTab("convert")}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded text-xs font-medium transition-colors ${
                currentTab === "convert"
                  ? "bg-sky-600 text-white"
                  : qtTheme === "dark" ? "text-slate-400 hover:bg-slate-800/60" : "text-stone-600 hover:bg-stone-250 hover:bg-stone-200"
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Batch Convert
            </button>
            <button
              onClick={() => setCurrentTab("history")}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded text-xs font-medium transition-colors ${
                currentTab === "history"
                  ? "bg-sky-600 text-white"
                  : qtTheme === "dark" ? "text-slate-400 hover:bg-slate-800/60" : "text-stone-600 hover:bg-stone-200"
              }`}
            >
              <History className="w-3.5 h-3.5" />
              Local Logs History
            </button>
            <button
              onClick={() => setCurrentTab("settings")}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded text-xs font-medium transition-colors ${
                currentTab === "settings"
                  ? "bg-sky-600 text-white"
                  : qtTheme === "dark" ? "text-slate-400 hover:bg-slate-800/60" : "text-stone-600 hover:bg-stone-200"
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              Engine Configs
            </button>
            <button
              onClick={() => setCurrentTab("license")}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded text-xs font-medium transition-colors ${
                currentTab === "license"
                  ? "bg-sky-600 text-white"
                  : qtTheme === "dark" ? "text-slate-400 hover:bg-slate-800/60" : "text-stone-600 hover:bg-stone-200"
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              Offline License
            </button>
          </div>

          {/* Quick Hardware Metadata ID block at the foot of navigation */}
          <div className={`p-2 rounded text-[10px] font-mono ${
            qtTheme === "dark" ? "bg-slate-900 border border-slate-800" : "bg-stone-200 border border-stone-300"
          }`}>
            <span className="text-slate-500 block mb-1">LOCAL MACHINE:</span>
            <span className="text-sky-500 block font-semibold overflow-hidden text-ellipsis">
              {licenseState.hardwareHash.substring(0, 15)}...
            </span>
            <span className="text-slate-500 block mt-1">STATUS:</span>
            <span className={licenseState.active ? "text-emerald-500 font-semibold" : "text-amber-500 font-semibold"}>
              {licenseState.active ? "● ACTIVE OK" : "● TRIAL ACTIVE"}
            </span>
          </div>
        </div>

        {/* Outer Tab Frames */}
        <div className="flex-1 flex flex-col p-4 overflow-y-auto max-h-[580px] custom-scrollbar">
          
          {/* TAB 1: BATCH CONVERT PAGE */}
          {currentTab === "convert" && (
            <div className="space-y-4 flex-1 flex flex-col justify-between">
              
              {/* Main controls top section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* File format toggling select options */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-500 block uppercase">
                    Conversion Profiles
                  </label>
                  <select
                    value={conversionType}
                    onChange={(e) => {
                      setConversionType(e.target.value);
                      logTerminal(`🔄 Switched active conversion profile to ${e.target.value}`);
                    }}
                    className={`w-full p-2 text-xs rounded border outline-none font-sans ${
                      qtTheme === "dark" 
                        ? "bg-slate-950 border-slate-800 text-slate-200" 
                        : "bg-white border-stone-300 text-stone-800"
                    }`}
                  >
                    <option value="pdf_to_docx">PDF (Scanned / Textual) to Microsoft Word (.docx)</option>
                    <option value="docx_to_pdf">Microsoft Word (.docx) to PDF Layout</option>
                    <option value="image_to_docx">Image files (PNG/JPG) to Word Document (via OCR)</option>
                    <option value="image_to_pdf">Image packages (PNG/JPG) to Multi-page PDF</option>
                  </select>
                </div>

                {/* Destination configuration path */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-500 block uppercase">
                    Output Directory (Offline SSD Only)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={selectedFolder}
                      onChange={(e) => setSelectedFolder(e.target.value)}
                      className={`flex-1 p-2 text-xs rounded border outline-none font-mono ${
                        qtTheme === "dark" 
                          ? "bg-slate-950 border-slate-800 text-slate-200" 
                          : "bg-white border-stone-300 text-stone-800"
                      }`}
                    />
                    <button 
                      onClick={() => logTerminal("📂 Invoked Native QFileDialog to select local output drive directory.")}
                      className="px-2.5 bg-slate-500/20 hover:bg-slate-500/35 border border-slate-500/50 rounded text-xs transition-colors py-1"
                    >
                      Browse
                    </button>
                  </div>
                </div>
              </div>

              {/* Drag drop Frame workspace */}
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`py-8 px-4 rounded-lg border-2 border-dashed flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                  dragActive 
                    ? "border-sky-500 bg-sky-500/10" 
                    : qtTheme === "dark" ? "border-slate-800 bg-slate-950/20 hover:bg-slate-950/40" : "border-stone-300 bg-stone-100 hover:bg-stone-150"
                }`}
              >
                <div className="p-3 bg-sky-500/10 rounded-full border border-sky-500/20 mb-2">
                  <FileText className="w-6 h-6 text-sky-500" />
                </div>
                <p className="text-xs font-semibold mb-1">Drag and Drop PDF, DOCX or Images here</p>
                <p className="text-[10px] text-slate-500 font-mono">Preserves local formatting, layouts and editable word structures offline</p>
              </div>

              {/* Conversion Queue File details */}
              {files.length > 0 ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-500 uppercase">
                      Queue (Batch of {files.length} documents)
                    </span>
                    <button 
                      onClick={clearQueue}
                      className="text-[10px] text-red-500 hover:underline flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" /> Clear Queue
                    </button>
                  </div>

                  <div className={`max-h-40 overflow-y-auto custom-scrollbar rounded border ${
                    qtTheme === "dark" ? "bg-slate-950/55 border-slate-800" : "bg-white border-stone-200"
                  }`}>
                    {files.map((file) => (
                      <div 
                        key={file.id} 
                        className={`flex items-center justify-between p-2 border-b text-xs last:border-0 ${
                          qtTheme === "dark" ? "border-slate-800/80 hover:bg-slate-900/60" : "border-stone-100 hover:bg-stone-50"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1">
                          <FileText className="w-4 h-4 text-sky-500 flex-shrink-0" />
                          <div className="min-w-0 pr-2">
                            <span className="font-medium truncate block">{file.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {file.pages} pages • {file.sizeMB} MB • OCR: {file.ocrApplied ? "PaddleOCR v4" : "None"}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {file.status === "Processing" && (
                            <div className="w-24 bg-slate-700 h-1.5 rounded-full overflow-hidden">
                              <div className="bg-sky-500 h-full animate-pulse" style={{ width: `${file.progress}%` }}></div>
                            </div>
                          )}
                          
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                            file.status === "Completed" 
                              ? "bg-emerald-500/15 text-emerald-500" 
                              : file.status === "Processing"
                              ? "bg-sky-500/15 text-sky-500"
                              : "bg-slate-500/15 text-slate-500"
                          }`}>
                            {file.status}
                          </span>

                          <button 
                            disabled={loading}
                            onClick={() => removeFile(file.id)}
                            className="p-1 hover:text-red-500 rounded disabled:opacity-30"
                          >
                            <XCircle className="w-3.5 h-3.5 text-slate-500 hover:text-red-500" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-slate-500 text-xs font-mono">
                  Queue is empty. Select or drag files to test.
                </div>
              )}

              {/* Action converting buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                <div className="flex items-center gap-2 text-[11px] text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>Standalone database sync checked</span>
                </div>
                
                <button
                  onClick={startConversion}
                  disabled={loading || files.length === 0}
                  className="px-5 py-2 rounded font-sans font-semibold text-xs transition-transform bg-sky-600 hover:bg-sky-500 text-white flex items-center gap-2 shadow disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5" />
                  {loading ? "Converting batch..." : "Run Offline conversion"}
                </button>
              </div>

              {/* Simulated main output terminal line logs */}
              <div className="mt-4 rounded border border-slate-800 bg-slate-950 p-2 font-mono text-[10px] text-zinc-400">
                <div className="flex items-center justify-between border-b border-slate-900 pb-1.5 mb-1.5 text-slate-500">
                  <span className="flex items-center gap-1.5"><Terminal className="w-3 h-3" /> Console Standard Output (Stdout logs)</span>
                  <button 
                    onClick={() => setTerminalLogs([])}
                    className="hover:text-zinc-300"
                  >
                    Clear stdout
                  </button>
                </div>
                <div className="max-h-24 overflow-y-auto space-y-0.5 custom-scrollbar">
                  {terminalLogs.map((log, i) => (
                    <div key={i} className="leading-relaxed break-all">
                      {log}
                    </div>
                  ))}
                  {loading && (
                    <div className="text-sky-400 animate-pulse">
                      [ENGINE PROCESS] processing line items...
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: HISTORY LOGS PAGE */}
          {currentTab === "history" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wide text-sky-500">
                    SQLite Local history files logs
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Showing query output of sqlite table <span className="font-mono font-semibold bg-slate-800/60 px-1 py-0.5 text-zinc-300">conversion_history</span>. Runs offline.
                  </p>
                </div>
                <div className="text-[10px] font-mono text-slate-500">
                  Storage location: C:\ProgramData\DocuForge\app.db
                </div>
              </div>

              {mockDatabaseLogs.length > 0 ? (
                <div className="overflow-x-auto rounded border border-slate-800">
                  <table className="w-full text-left text-[11px] font-sans">
                    <thead className={`font-mono border-b ${
                      qtTheme === "dark" ? "bg-slate-950 text-slate-400 border-slate-800" : "bg-stone-200 text-stone-700 border-stone-300"
                    }`}>
                      <tr>
                        <th className="p-2">ID</th>
                        <th className="p-2">Filename</th>
                        <th className="p-2">Extension</th>
                        <th className="p-2">Action Profile</th>
                        <th className="p-2">OCR Applied</th>
                        <th className="p-2">Speed (Sec)</th>
                        <th className="p-2">Time</th>
                        <th className="p-2">Rows Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {mockDatabaseLogs
                        .filter(log => log.action.includes("INSERT"))
                        .map((log, idx) => {
                          // Try to parse details from the SQL text
                          const sqlStr = log.sql;
                          const nameMatch = sqlStr.match(/VALUES \('([^']+)'/);
                          const typeMatch = sqlStr.match(/'([^']+)', '[^']+', 'SUCCESS'/);
                          const ocrMatch = sqlStr.match(/SUCCESS', [0-9]+, (1|0)/);
                          const speedMatch = sqlStr.match(/, ([0-9.]+)\);/);

                          const filename = nameMatch ? nameMatch[1] : "Sample.pdf";
                          const action = typeMatch ? typeMatch[1] : "pdf_to_docx";
                          const ocrStr = ocrMatch && ocrMatch[1] === "1" ? "✅ Yes" : "❌ No";
                          const speed = speedMatch ? speedMatch[1] : "1.45";

                          return (
                            <tr key={idx} className={qtTheme === "dark" ? "hover:bg-slate-900/40" : "hover:bg-stone-100"}>
                              <td className="p-2 font-mono text-slate-500">{mockDatabaseLogs.length - idx}</td>
                              <td className="p-2 font-semibold truncate max-w-40">{filename}</td>
                              <td className="p-2 font-mono text-[10px] text-zinc-400">.{filename.split(".").pop()}</td>
                              <td className="p-2 font-mono text-[10px] text-sky-400">{action}</td>
                              <td className="p-2">{ocrStr}</td>
                              <td className="p-2 font-mono">{speed}s</td>
                              <td className="p-2 text-slate-400">{log.timestamp}</td>
                              <td className="p-2">
                                <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-500/10 text-emerald-500 border border-emerald-500/15">
                                  SUCCESS
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-10 border border-dashed border-slate-800 rounded text-slate-500 font-mono text-xs">
                  No records stored yet. Execute and process the conversion queue above to trigger SQLite inserts.
                </div>
              )}
              
              <div className="rounded p-3 bg-indigo-500/5 border border-indigo-500/25">
                <span className="text-[11px] font-bold text-indigo-400 uppercase block mb-1">Architecture Note from Principal Engineer:</span>
                <p className="text-[10px] leading-relaxed text-zinc-400">
                  SQLite database file locks check ensures safe write operations even when desktop workers process multiple items concurrently. It uses write-ahead logging (WAL) configurations to secure performance on local hard disks.
                </p>
              </div>

            </div>
          )}

          {/* TAB 3: ENGINE CONFIG PAGE */}
          {currentTab === "settings" && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wide text-sky-500">
                Offline Desktop Application Settings
              </h4>
              <p className="text-[11px] text-slate-500">
                These settings parse PySide config dictionaries cached locally in user profile profiles.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* OCR Toggle */}
                <div className={`p-3 rounded border space-y-2 ${
                  qtTheme === "dark" ? "bg-slate-950/60 border-slate-800" : "bg-white border-stone-200"
                }`}>
                  <span className="text-[11px] font-bold uppercase text-slate-400 block"><Cpu className="w-3.5 h-3.5 inline mr-1" /> PaddleOCR Offline Configuration</span>
                  
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-500 block">OCR trigger conditions:</span>
                    <div className="flex gap-1.5 flex-col pl-1">
                      <label className="flex items-center gap-2 text-xs">
                        <input 
                          type="radio" 
                          name="ocr" 
                          checked={ocrMode === "scan"} 
                          onChange={() => setOcrMode("scan")} 
                        />
                        <span>Only on scanned images/PDF page cuts (Smart)</span>
                      </label>
                      <label className="flex items-center gap-2 text-xs">
                        <input 
                          type="radio" 
                          name="ocr" 
                          checked={ocrMode === "always"} 
                          onChange={() => setOcrMode("always")} 
                        />
                        <span>Forced OCR for every conversion output (Slower)</span>
                      </label>
                      <label className="flex items-center gap-2 text-xs">
                        <input 
                          type="radio" 
                          name="ocr" 
                          checked={ocrMode === "never"} 
                          onChange={() => setOcrMode("never")} 
                        />
                        <span>Disable local OCR logic completely</span>
                      </label>
                    </div>
                  </div>
                </div>

                {/* Layout preservation settings */}
                <div className={`p-3 rounded border space-y-2 ${
                  qtTheme === "dark" ? "bg-slate-950/60 border-slate-800" : "bg-white border-stone-200"
                }`}>
                  <span className="text-[11px] font-bold uppercase text-slate-400 block"><Grid className="w-3.5 h-3.5 inline mr-1" /> Layout Preservation</span>
                  
                  <div className="space-y-2">
                    <label className="flex items-center justify-between text-xs">
                      <span>Preserve complex document margins</span>
                      <input 
                        type="checkbox" 
                        checked={preserveLayout} 
                        onChange={(e) => setPreserveLayout(e.target.checked)} 
                      />
                    </label>
                    <label className="flex items-center justify-between text-xs">
                      <span>Enable force-grid native table analyzer</span>
                      <input 
                        type="checkbox" 
                        checked={tableGridForce} 
                        onChange={(e) => setTableGridForce(e.target.checked)} 
                      />
                    </label>
                    <div className="text-[10px] text-slate-500">
                      Calculates paragraph clusters and cell geometry based on local mathematical boundary intersections.
                    </div>
                  </div>
                </div>
              </div>

              <div className={`p-3 rounded border text-xs leading-relaxed ${
                qtTheme === "dark" ? "bg-slate-950/30 border-slate-800" : "bg-stone-100 border-stone-200"
              }`}>
                <span className="block font-bold mb-1">Temporary Cache Engine Optimizer</span>
                <p className="text-slate-500 text-[11px]">
                  Failsafe cleaning removes temporary page files, extracted text blocks, and OCR buffer segments dynamically on conversions window termination. Auto cleanup is verified OK.
                </p>
              </div>
            </div>
          )}

          {/* TAB 4: OFFLINE LICENSE PAGE */}
          {currentTab === "license" && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-sky-500" />
                <h4 className="text-xs font-bold uppercase tracking-wide text-sky-500">
                  Offline Activation Key Validation state
                </h4>
              </div>

              <div className={`p-3.5 rounded border leading-relaxed text-xs space-y-3 ${
                qtTheme === "dark" ? "bg-slate-950/65 border-slate-800" : "bg-white border-stone-200"
              }`}>
                
                <div className="flex justify-between border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Activation Binding Profile:</span>
                  <span className="font-mono font-bold text-[11px] bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded text-sky-400">
                    CPU_BIOS_SIGNATURE_HASH
                  </span>
                </div>

                <div className="flex justify-between border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Current Computed Hardware Signature:</span>
                  <span className="font-mono text-[11px] text-zinc-300">
                    {licenseState.hardwareHash}
                  </span>
                </div>

                <div className="flex justify-between border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Licensing State:</span>
                  <span className={`font-semibold capitalize ${licenseState.active ? "text-emerald-500" : "text-amber-500"}`}>
                    {licenseState.active ? "Premium Active ✓" : "Evaluation Mode (Unactivated)"}
                  </span>
                </div>

                {licenseState.active && (
                  <>
                    <div className="flex justify-between border-b border-slate-800/80 pb-2">
                      <span className="text-slate-400">Activated At:</span>
                      <span className="text-zinc-300 font-mono text-[10px]">{licenseState.activatedAt}</span>
                    </div>

                    <div className="flex justify-between border-b border-slate-800/80 pb-2">
                      <span className="text-slate-400">Expiration Date (3-Month Deadline):</span>
                      <span className="text-zinc-300 font-mono text-[10px]">{licenseState.expiresAt}</span>
                    </div>

                    <div className="flex justify-between border-b border-slate-800/80 pb-2">
                      <span className="text-slate-400">Subscription Days Left:</span>
                      <span className="font-mono text-emerald-500 font-bold">{licenseState.daysRemaining} days</span>
                    </div>
                  </>
                )}

              </div>

              {!licenseState.active ? (
                <div className="rounded p-3 bg-amber-500/5 border border-amber-500/20 text-xs text-amber-500 space-y-2">
                  <span className="font-bold flex items-center gap-1.5"><ShieldAlert className="w-4 h-4" /> Activation Instructions:</span>
                  <p className="text-[11px] text-amber-400 leading-relaxed">
                    1. Go to the **Offline Activation Portal** tab above on the web dashboard to generate a secure activation key bound to this hardware hash.
                    <br />
                    2. Paste the generated key into the field below and trigger activation!
                  </p>
                </div>
              ) : (
                <div className="rounded p-2 bg-emerald-500/5 border border-emerald-500/20 text-xs text-emerald-500">
                  ✓ premium enterprise licensing checks completed successfully. Anti-date tampering sensors calibrated.
                </div>
              )}

              {/* Paste license key segment */}
              {!licenseState.active && (
                <div className="space-y-1.5 pt-1">
                  <label className="text-[10px] font-semibold text-slate-500 uppercase block">
                    Submit offline activation key:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="DF-xxxx..."
                      id="sim-license-input"
                      className={`flex-1 p-2 text-xs rounded border outline-none font-mono ${
                        qtTheme === "dark" 
                          ? "bg-slate-950 border-slate-800 text-slate-200" 
                          : "bg-white border-stone-300 text-stone-800"
                      }`}
                    />
                    <button
                      onClick={() => {
                        const val = (document.getElementById("sim-license-input") as HTMLInputElement)?.value?.trim();
                        if (!val) {
                          alert("Please paste a license key from the Activation Portal first!");
                          return;
                        }
                        if (!val.startsWith("DF-")) {
                          logTerminal("❌ License Activation failed: Key does not start with valid block signatures.");
                          return;
                        }
                        try {
                          const base64Part = val.substring(3);
                          const decoded = atob(base64Part);
                          const obj = JSON.parse(decoded);
                          
                          if (obj.hwid !== licenseState.hardwareHash) {
                            logTerminal("❌ License Activation failed: Key is bound to another hardware fingerprint!");
                            return;
                          }

                          // Success activation
                          const today = new Date();
                          const expiryDate = new Date();
                          expiryDate.setDate(today.getDate() + 90);

                          setLicenseState({
                            active: true,
                            rawKey: val,
                            hardwareHash: licenseState.hardwareHash,
                            activatedAt: today.toISOString().split("T")[0],
                            expiresAt: expiryDate.toISOString().split("T")[0],
                            daysRemaining: 90,
                            tier: "Enterprise Pro (Offline)",
                            reason: "",
                          });

                          setMockDatabaseLogs(prev => [
                            {
                              timestamp: new Date().toLocaleTimeString(),
                              action: "SQLite INSERT row",
                              sql: `INSERT OR REPLACE INTO license_info (id, activation_key, hardware_hash, activated_at, expires_at, last_seen_time) VALUES (1, '${val}', '${licenseState.hardwareHash}', '${today.toISOString().split("T")[0]}', '${expiryDate.toISOString().split("T")[0]}', '${new Date().toLocaleTimeString()}');`
                            },
                            ...prev
                          ]);

                          logTerminal("🎉 PRODUCT ACTIVATED SUCCESSFULLY. Premium suite features unlocked. Wallets authorized offline.");
                        } catch (e) {
                          logTerminal("❌ License Activation failed: Cryptographic decoding failure.");
                        }
                      }}
                      className="px-4 py-2 bg-sky-600 hover:bg-sky-500 rounded text-xs text-white font-semibold flex items-center gap-1"
                    >
                      Activate
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>
      </div>

      {/* Database log triggers list at the foot of index page */}
      <div className={`p-2.5 px-4 text-[10px] font-mono border-t flex justify-between items-center ${
        qtTheme === "dark" ? "bg-slate-950/90 border-slate-800 text-slate-500" : "bg-stone-100 border-stone-200 text-stone-600"
      }`}>
        <div className="flex items-center gap-1.5">
          <Database className="w-3.5 h-3.5 text-zinc-400" />
          <span>Local SQLite Connection Mode: <b className="text-zinc-400">ACTIVE</b></span>
        </div>
        
        <div>
          <span>Total Database Logs Committed: <b>{mockDatabaseLogs.length}</b></span>
        </div>
      </div>
    </div>
  );
}
