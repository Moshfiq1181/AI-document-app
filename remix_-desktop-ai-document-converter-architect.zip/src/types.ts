export interface FileNode {
  name: string;
  type: "file" | "directory";
  description?: string;
  children?: FileNode[];
}

export interface TableColumn {
  name: string;
  type: string;
  desc: string;
}

export interface TableSchema {
  table: string;
  description: string;
  columns: TableColumn[];
}

export interface ConversionItem {
  id: string;
  sourceName: string;
  sourceType: string;
  destinationPath: string;
  conversionType: string;
  status: "PENDING" | "RUNNING" | "SUCCESS" | "FAILED";
  progress: number;
  totalPages: number;
  ocrApplied: boolean;
  durationSeconds?: number;
  timestamp: string;
  sizeMB: number;
}

export interface LicenseState {
  active: boolean;
  rawKey: string;
  hardwareHash: string;
  activatedAt: string;
  expiresAt: string;
  daysRemaining: number;
  tier: string;
  reason: string;
}
